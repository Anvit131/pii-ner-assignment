import sys
sys.path.append('/content')
sys.path.append('/content/src')

import argparse
from transformers import (
    AutoTokenizer,
    AutoModelForTokenClassification,
    TrainingArguments,
    Trainer,
    DataCollatorForTokenClassification
)
from src.dataset import build_hf_dataset, LABEL_LIST

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", default="distilbert-base-uncased")
    parser.add_argument("--train", default="data/train.jsonl")
    parser.add_argument("--dev", default="data/dev.jsonl")
    parser.add_argument("--out_dir", default="out/distil_baseline")
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--batch_size", type=int, default=8)
    args = parser.parse_args()

    tokenizer = AutoTokenizer.from_pretrained(args.model_name, use_fast=True)
    train_ds = build_hf_dataset(tokenizer, args.train)
    dev_ds = build_hf_dataset(tokenizer, args.dev)

    model = AutoModelForTokenClassification.from_pretrained(
        args.model_name,
        num_labels=len(LABEL_LIST)
    )

    # 🔥 FIX: Automatic padding for input + labels
    data_collator = DataCollatorForTokenClassification(tokenizer)

    training_args = TrainingArguments(
        output_dir=args.out_dir,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        num_train_epochs=args.epochs,
        logging_steps=50,
        save_steps=500,
        eval_steps=500,
        logging_dir="logs",
        do_eval=True,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=dev_ds,
        tokenizer=tokenizer,
        data_collator=data_collator     # ⭐ VERY IMPORTANT
    )

    trainer.train()
    trainer.save_model(args.out_dir)

if __name__ == "__main__":
    main()
