import json, re, argparse, torch
from transformers import AutoTokenizer, AutoModelForTokenClassification
from src.dataset import LABEL_LIST

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")

def normalize(text):
    return text.replace(" at ", "@").replace(" dot ", ".")

def bio_to_spans(tokens, labels, offsets, text):
    spans = []
    curr = None
    for i, lid in enumerate(labels):
        lab = LABEL_LIST[lid]
        if lab.startswith("B-"):
            if curr:
                spans.append(curr)
            curr = {"label": lab[2:], "start": offsets[i][0], "end": offsets[i][1]}
        elif lab.startswith("I-") and curr:
            curr["end"] = offsets[i][1]
        else:
            if curr:
                spans.append(curr)
                curr = None
    if curr:
        spans.append(curr)

    for s in spans:
        s["text"] = text[s["start"]:s["end"]]
    return spans

def is_valid(span):
    if span["label"] == "EMAIL":
        return EMAIL_RE.match(normalize(span["text"])) is not None
    return True

def run_prediction(model_dir="out/distil_baseline",
                   input_path="data/dev.jsonl",
                   output_path="out/dev_pred.json"):

    tok = AutoTokenizer.from_pretrained(model_dir)
    model = AutoModelForTokenClassification.from_pretrained(model_dir)
    model.eval()

    data = [json.loads(l) for l in open(input_path)]
    out = []

    for item in data:
        text = item["text"]
        enc = tok(text, return_offsets_mapping=True, return_tensors="pt")

        with torch.no_grad():
            pred = model(enc["input_ids"], attention_mask=enc["attention_mask"]).logits.argmax(-1)[0]

        spans = bio_to_spans(
            tok.convert_ids_to_tokens(enc["input_ids"][0]),
            pred.tolist(),
            enc["offset_mapping"][0].tolist(),
            text
        )

        final = [s for s in spans if is_valid(s)]
        for f in final:
            f["pii"] = True

        out.append({
            "id": item["id"],
            "text": text,
            "predicted_entities": final
        })

    with open(output_path, "w") as f:
        for x in out:
            f.write(json.dumps(x) + "\n")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_dir", default="out/distil_baseline")
    parser.add_argument("--input", default="data/dev.jsonl")
    parser.add_argument("--output", default="out/dev_pred.json")
    args = parser.parse_args()
    run_prediction(args.model_dir, args.input, args.output)

if __name__ == "__main__":
    main()
