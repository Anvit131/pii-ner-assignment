import json
from datasets import Dataset

LABEL_LIST = [
    "O",
    "B-CREDIT_CARD","I-CREDIT_CARD",
    "B-PHONE","I-PHONE",
    "B-EMAIL","I-EMAIL",
    "B-PERSON_NAME","I-PERSON_NAME",
    "B-DATE","I-DATE",
    "B-CITY","I-CITY",
]

label_to_id = {l:i for i,l in enumerate(LABEL_LIST)}

def read_jsonl(path):
    return [json.loads(l) for l in open(path,"r")]

def char_labels_to_token_labels(tokenizer, text, entities):
    enc = tokenizer(text, return_offsets_mapping=True, truncation=True)
    offsets = enc["offset_mapping"]
    labels = ["O"] * len(offsets)

    for ent in entities:
        s, e, lab = ent["start"], ent["end"], ent["label"]
        started = False
        for i,(os,oe) in enumerate(offsets):
            if oe<=s or os>=e: 
                continue
            if not started:
                labels[i] = "B-"+lab
                started = True
            else:
                labels[i] = "I-"+lab

    return enc, [label_to_id[l] for l in labels]

def build_hf_dataset(tokenizer, path):
    data = read_jsonl(path)
    inputs=[]; masks=[]; lbls=[]; offs=[]; texts=[]
    for item in data:
        enc, ids = char_labels_to_token_labels(tokenizer,item["text"],item["entities"])
        inputs.append(enc["input_ids"])
        masks.append(enc["attention_mask"])
        lbls.append(ids)
        offs.append(enc["offset_mapping"])
        texts.append(item["text"])

    return Dataset.from_dict({
        "input_ids":inputs,
        "attention_mask":masks,
        "labels":lbls,
        "offset_mapping":offs,
        "text":texts
    })
