import json
import random
import uuid
from pathlib import Path

NAMES = ["john", "mary", "alice", "bob", "mohammed", "anvit", "ravi", "sneha", "arjun", "kiran"]
DOMAINS = ["gmail", "yahoo", "example", "outlook"]
CITIES = ["mumbai", "chennai", "delhi", "bangalore", "kolkata"]
FILLERS = ["uh", "okay", "you know", "like"]

MAP_DIGIT = {
    '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four',
    '5': 'five', '6': 'six', '7': 'seven', '8': 'eight', '9': 'nine'
}

def random_name():
    name = random.choice(NAMES)
    if random.random() < 0.25:
        sec = random.choice(NAMES)
        if sec != name:
            name = name + " " + sec
    return name

def make_email():
    local = random.choice(NAMES)
    if random.random() < 0.2:
        local = " ".join(list(local))
    local = local.replace(" ", " dot ")
    return f"{local} at {random.choice(DOMAINS)} dot com", "EMAIL"

def make_phone():
    digits = ''.join(random.choice('0123456789') for _ in range(10))
    if random.random() < 0.5:
        return " ".join(MAP_DIGIT[d] for d in digits), "PHONE"
    return digits, "PHONE"

def make_credit():
    digits = ''.join(random.choice('0123456789') for _ in range(16))
    return " ".join(MAP_DIGIT[d] for d in digits), "CREDIT_CARD"

def make_date():
    day = random.randint(1, 28)
    month = random.choice(["january","february","march","april","may","june",
                           "july","august","september","october","november","december"])
    year = random.choice(["two thousand twenty", "twenty twenty one"])
    return f"{day} of {month} {year}", "DATE"

def make_city():
    return random.choice(CITIES), "CITY"

ENTITY_MAKERS = [make_email, make_phone, make_credit, make_date, random_name, make_city]

def generate_example():
    base = ["i", "think", "my", "account", "is", "with"]
    if random.random() < 0.3:
        base.insert(0, random.choice(FILLERS))
    text = " ".join(base)

    entities = []
    maker = random.choice(ENTITY_MAKERS)
    if maker == random_name:
        ent_text = maker()
        label = "PERSON_NAME"
    else:
        ent_text, label = maker()
    text = text + " " + ent_text
    start = text.find(ent_text)
    end = start + len(ent_text)

    return {"id": str(uuid.uuid4())[:8], "text": text, "entities": [{"start": start, "end": end, "label": label}]}

def write_dataset():
    Path("data").mkdir(exist_ok=True)
    with open("data/train.jsonl", "w") as t:
        for _ in range(800):
            t.write(json.dumps(generate_example()) + "\n")
    with open("data/dev.jsonl", "w") as d:
        for _ in range(150):
            d.write(json.dumps(generate_example()) + "\n")

if __name__ == "__main__":
    random.seed(42)
    write_dataset()
